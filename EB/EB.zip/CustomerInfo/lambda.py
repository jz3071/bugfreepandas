# # -*- coding: utf-8 -*-
# # @Time    : 2019/11/7 11:35
# # @Author  : Yunjie Cao
# # @FileName: lambda.py
# # @Software: PyCharm
# # @Email   ：YunjieCao@hotmail.com

# import json
# import jwt

# def lambda_handler(event, context):
#     # TODO implement

#     SECRET_KEY="\xf9'\xe4p(\xa9\x12\x1a!\x94\x8d\x1c\x99l\xc7\xb7e\xc7c\x86\x02MJ\xa0"
#     compact_jws = jwt.encode(context, SECRET_KEY, 'HS256')

#     message_received = jwt.decode(compact_jws, SECRET_KEY)

#     print(message_received)

#     return {
#         'statusCode': 200,
#         'body': json.dumps('Hello from Lambda!'),
#         'msg': 'hello world'
#     }


# if __name__=="__main__":
#     context = {
#         'first_name': 'yunjie',
#         'last_name': 'cao',
#         'email': 'yc3702@columbia.edu'
#     }
#     lambda_handler(None, context)